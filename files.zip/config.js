// ─────────────────────────────────────────────
//  CONFIGURACIÓN — Edita estos valores
// ─────────────────────────────────────────────

const CONFIG = {
  // Código que darás a tus amigos para entrar
  ACCESS_CODE: 'cine2025',

  // Tu código privado para ver el panel de propietario
  OWNER_CODE: 'milistaprivada',

  // Tu API key de TMDB (https://www.themoviedb.org/settings/api)
  TMDB_API_KEY: 'TU_TMDB_API_KEY_AQUI',

  // URL de tu proyecto en Supabase (https://supabase.com → Settings → API)
  SUPABASE_URL: 'https://TUPROYECTO.supabase.co',

  // Clave pública (anon key) de Supabase
  SUPABASE_ANON_KEY: 'TU_SUPABASE_ANON_KEY_AQUI',

  // Idioma de resultados de TMDB ('es-ES', 'en-US', etc.)
  TMDB_LANGUAGE: 'es-ES',
};
